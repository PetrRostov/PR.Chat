You can find full list of changes in changes.txt, list of breaking changes in breakingchanges.txt.

Online release notes:  http://docs.castleproject.org/Windsor.Whats-New-In-Windsor-3.ashx
Documentation:         http://docs.castleproject.org/Windsor.MainPage.ashx
Samples:               http://docs.castleproject.org/Windsor.MainPage.ashx?#Samples_8
Issue tracker:         http://issues.castleproject.org/dashboard
Discusssion group:     http://groups.google.com/group/castle-project-users
StackOverflow tags:    castle-windsor, castle